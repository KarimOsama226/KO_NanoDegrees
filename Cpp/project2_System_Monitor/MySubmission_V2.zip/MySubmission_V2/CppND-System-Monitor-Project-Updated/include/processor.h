#ifndef PROCESSOR_H
#define PROCESSOR_H
#include <vector>
using std::vector ;
class Processor {
 public:
  float Utilization();  // Done: See src/processor.cpp

  // Done: Declare any necessary private members
 private:
    long prev_active_jiffies_ = 0;
    long prev_total_jiffies_ = 0;

    vector<long> ReadCpuStats();
    long ActiveJiffies(const vector<long>& cpu_stats);
    long TotalJiffies(const vector<long>& cpu_stats);
};

#endif
#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"
#include "linux_parser.h"
#include <iostream>

using std::string;
using std::to_string;
using std::vector;
using std::stoi;
using std::cout;
// Done: Return this process's ID
int Process::Pid() 
{
    return pid;
}

// Done: Return this process's CPU utilization
float Process::CpuUtilization() const
{
    #if 0
   string key,value,line;
    vector<string> values ;
    float Hertz = sysconf(_SC_CLK_TCK);
    std::ifstream file(LinuxParser::kProcDirectory+to_string(pid)+LinuxParser::kStatFilename);
    if(file.is_open()){
        std::getline(file,line);
        std::istringstream linestream(line) ; 
        for (int i = 0; i < 22 ; i++)
        {
            linestream >> value ; 
            values.push_back(value);
        }
    }
    file.close();
    float totalTime = float(stoi(values[13]) + (stoi(values[14])) + (stoi(values[15])) + (stoi(values[16])));
    float seconds = LinuxParser::UpTime()-(stoi(values[21])/Hertz);
    float cpuUtil = ((totalTime/Hertz)/seconds);
 //   cout << "the total time is : " << totalTime << "and the Seconds are  " << seconds << "while Hz is " <<Hertz << "\n";
     return cpuUtil ;
 #endif
     return float(LinuxParser::ActiveJiffies(pid))/float(LinuxParser::UpTime(pid));
}

// Done: Return the command that generated this process
string Process::Command()
{
    return LinuxParser::Command(pid); 
} 

// Done: Return this process's memory utilization
string Process::Ram()
{
    return LinuxParser::Ram(pid);
}

// Done: Return the user (name) that generated this process
string Process::User() 
{ 
    return LinuxParser::User(pid);    
}

// Done: Return the age of this process (in seconds)
long int Process::UpTime() 
{ 
    return LinuxParser::UpTime(pid);
}

// Done: Overload the "less than" comparison operator for Process objects
bool Process::operator<(Process const& a) const 
{ 
    return (a.CpuUtilization() < this -> CpuUtilization());
}
Process::Process(int pid) : pid(pid) {};
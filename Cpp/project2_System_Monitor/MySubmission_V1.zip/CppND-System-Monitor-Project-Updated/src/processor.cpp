#include "processor.h"
#include "linux_parser.h" // Include the LinuxParser namespace header

// Done: Return the aggregate CPU utilization
float Processor::Utilization() 
{ 
    #if 0
    float cpuUtil{0.0};
    long activeJiff = LinuxParser::ActiveJiffies();
    long totalJiff = LinuxParser::Jiffies();
    // Calculate the deltas (difference between current and previous values)
    long delta_active = activeJiff - this->prev_active_jiffies_;
    long delta_total = totalJiff - this->prev_total_jiffies_;

    // Update the stored previous values
    this->prev_active_jiffies_ = activeJiff;
    this->prev_total_jiffies_ = totalJiff;

    // Avoid division by zero
    if (delta_total == 0) {
        return 0.0;
    }
    cpuUtil = delta_active/delta_total;
#endif
  float  cpuUtil =  float(LinuxParser::ActiveJiffies())/float(LinuxParser::Jiffies());
    return cpuUtil;
}
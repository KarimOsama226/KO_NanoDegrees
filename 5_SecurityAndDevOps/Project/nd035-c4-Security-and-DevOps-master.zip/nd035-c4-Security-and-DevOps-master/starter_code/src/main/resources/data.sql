insert into item (name, price, description) values ('Round Widget', 2.99, 'A widget that is round');
insert into item (name, price, description) values ('Square Widget', 1.99, 'A widget that is square');
insert into item (name, price, description) values ('White rice', 0.57, 'A delicious food');
insert into item (name, price, description) values ('Eggs & Bacon', 6.75, 'Protein for your muscles');
insert into item (name, price, description) values ('Sugar powder', 4.59, 'Cook and enjoy');
insert into item (name, price, description) values ('Soccer ball', 21.6, 'Play with your guys');
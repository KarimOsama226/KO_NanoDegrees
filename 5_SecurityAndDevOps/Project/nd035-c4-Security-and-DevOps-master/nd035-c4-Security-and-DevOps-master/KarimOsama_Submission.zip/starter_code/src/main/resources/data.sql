insert into item (name, price, description) values ('Round Widget', 2.99, 'A widget that is round');
insert into item (name, price, description) values ('Square Widget', 1.99, 'A widget that is square');
insert into item (name, price, description) values ('Whey', 6.0, 'Isolated');
insert into item (name, price, description) values ('Creatine', 5.1, 'Bulk Up');
insert into item (name, price, description) values ('Preworkout', 10.5, 'Pump Up');

package com.database_example.DatabasesDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabasesDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabasesDemoApplication.class, args);
	}

}
